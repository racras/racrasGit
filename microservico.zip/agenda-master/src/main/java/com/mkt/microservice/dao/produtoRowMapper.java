package com.mkt.microservice.dao;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Component;

import com.mkt.microservice.entity.Produto_tb;


/* essa bagaça roda a cada linha mapeando os campos para o POJO "produto_tb" */
@Component
public class produtoRowMapper implements RowMapper<Produto_tb> {

	@Override
	public Produto_tb mapRow(ResultSet rs, int rowNum) throws SQLException {
		Produto_tb produto = new Produto_tb();
		produto.setproduto_id(rs.getInt("produto_id"));
		produto.setNome(rs.getString("nome"));
		produto.setseguradora_cod_susep(rs.getString("seguradora_cod_susep"));
		produto.setnum_max_parcela(rs.getString("num_max_parcela"));
		return produto;
	}
}