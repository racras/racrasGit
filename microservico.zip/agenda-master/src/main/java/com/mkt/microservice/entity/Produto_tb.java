package com.mkt.microservice.entity;

/**
 * Esse é um POJO (Plain Old Java Object) 
 * É o método mais comum usado para transportar dados no java.
*/

public class Produto_tb {
	private Integer produto_id;
	private String nome;
	private String seguradora_cod_susep;
	private String num_max_parcela;

	public Integer getproduto_id() {
		return produto_id;
	}

	public void setproduto_id(Integer produto_id) {
		this.produto_id = produto_id;
	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getseguradora_cod_susep() {
		return seguradora_cod_susep;
	}

	public void setseguradora_cod_susep(String seguradora_cod_susep) {
		this.seguradora_cod_susep = seguradora_cod_susep;
	}

	public String getnum_max_parcela() {
		return num_max_parcela;
	}

	public void setnum_max_parcela(String num_max_parcela) {
		this.num_max_parcela = num_max_parcela;
	}
}
