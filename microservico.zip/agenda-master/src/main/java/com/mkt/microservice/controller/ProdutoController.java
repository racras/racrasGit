package com.mkt.microservice.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.mkt.microservice.entity.Produto_tb;

public interface ProdutoController {
    ResponseEntity<List<Produto_tb>> get();
    ResponseEntity<Produto_tb> get(@PathVariable Integer produto_id);
	ResponseEntity<Produto_tb> post(@RequestBody Produto_tb produto);
	ResponseEntity<Produto_tb> update(@RequestBody Produto_tb produto);
	ResponseEntity<Produto_tb> delete(@RequestBody Produto_tb produto);
}
