package com.mkt.microservice.service;

import java.util.List;

import com.mkt.microservice.entity.Produto_tb;

/**
 * Esse é um exemplo de interface.
 * Que é um "mapa" de implementação de um "tipo de objeto".
 * Aqui você define como seu objeto vai ser implementado.
 * Veja a implementação na classe ProdutoServiceImpl.
 * */

public interface ProdutoService {
	public List<Produto_tb> get();
	public Produto_tb get(Integer produto_id);
	public void insert(Produto_tb produto);
	public void update(Produto_tb produto);
	public void push(Produto_tb produto);
	public void delete(Produto_tb produto);
}
