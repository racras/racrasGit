package com.mkt.microservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;
import com.mkt.microservice.dao.ProdutoDAO;
import com.mkt.microservice.entity.Produto_tb;

/**
 * Esse é o service.
 * Aqui é onde são tratadas as regras de negócio.
 * Quase sempre faz nada e repassa a camada DAO.
*/

@Service
public class ProdutoServiceImpl implements ProdutoService {
	
	@Autowired private ProdutoDAO dao;
	
	public List<Produto_tb> get() {
		return dao.get();
	}

	public Produto_tb get(Integer id) {
		return dao.get(id);
	}

	public void insert(Produto_tb produto) {
		dao.insert(produto);
	}

	public void update(Produto_tb produto) {
		dao.update(produto);
	}

	public void push(Produto_tb produto_tb) {
		Produto_tb reg = null;
		
		try {
			reg = dao.get(produto_tb.getproduto_id());
		} catch(EmptyResultDataAccessException e) {
		}
		
		if(reg==null) {
			dao.insert(produto_tb);
		} else {
			dao.update(produto_tb);
		}
	}

	public void delete(Produto_tb produto_tb) {
		dao.delete(produto_tb);
	}
}
