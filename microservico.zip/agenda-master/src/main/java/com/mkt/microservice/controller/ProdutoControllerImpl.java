package com.mkt.microservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.mkt.microservice.entity.Produto_tb;
import com.mkt.microservice.service.ProdutoService;


/**
 * Esse é o controller.
 * Aqui começa o processo.
 * Onde são recebidas e tratadas as requisições.
 * Os dados recebidos são passados para a camada service.
*/

@CrossOrigin
@RestController
@RequestMapping("/servico")
public class ProdutoControllerImpl implements ProdutoController {
	
	@Autowired private ProdutoService service;

	@GetMapping("/produto")
	public ResponseEntity<List<Produto_tb>> get() {
		List<Produto_tb> get = service.get();
		return new ResponseEntity<>(get, HttpStatus.OK);
    }

	@GetMapping(value="/produto/{produto_id}")
	public ResponseEntity<Produto_tb> get(@PathVariable Integer produto_id) {
		Produto_tb get = service.get(produto_id);
		return new ResponseEntity<>(get, HttpStatus.OK);
    }
	
	@PostMapping(value = "/produto")
	public ResponseEntity<Produto_tb> post(@RequestBody Produto_tb produto) {
		service.insert(produto);
		return new ResponseEntity<>(HttpStatus.OK);
    }
	
	@RequestMapping(value = "/produto", method = RequestMethod.PUT)
	public ResponseEntity<Produto_tb> update(@RequestBody Produto_tb produto) {
		service.update(produto);
		return new ResponseEntity<>(HttpStatus.OK);
    }

	@RequestMapping(value = "/produto", method = RequestMethod.DELETE)
	public ResponseEntity<Produto_tb> delete(@RequestBody Produto_tb produto) {
		service.delete(produto);
		return new ResponseEntity<>(HttpStatus.OK);
    }
	
}
