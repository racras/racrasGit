package com.mkt.microservice.dao;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.mkt.microservice.entity.Produto_tb;


@Repository
public interface ProdutoDAO {
	public List<Produto_tb> get();

	public Produto_tb get(Integer integer);

	public void insert(Produto_tb produto);
	
	public void update(Produto_tb produto);

	public void delete(Produto_tb produto);
}
