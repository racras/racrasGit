package com.mkt.microservice.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.mkt.microservice.entity.Produto_tb;

/**
 * Esse é o dao (Data Access Object).
 * Aqui é onde as operações de banco são tratadas.
*/
@Repository
public class ProdutoDAOImpl implements ProdutoDAO {

	@Autowired private JdbcTemplate jdbcTemplate;
	@Autowired private RowMapper<Produto_tb> produtoRowMapper;

	public List<Produto_tb> get() {
		return jdbcTemplate.query("select produto_id, nome ,seguradora_cod_susep, num_max_parcela from produto_tb order by produto_id", produtoRowMapper);
	}

	public Produto_tb get(Integer integer) {
		return jdbcTemplate.queryForObject("select produto_id, nome ,seguradora_cod_susep, num_max_parcela from produto_tb where produto_id=?", new Object[] { integer }, produtoRowMapper);
	}

	public void insert(Produto_tb produto) {
		String sql = "insert into produto_tb(produto_id, nome ,seguradora_cod_susep, num_max_parcela) values (?, ?, ?, ?)";
		List<Object> values = new ArrayList<>();
		values.add(produto.getproduto_id());
        values.add(produto.getNome());
        values.add(produto.getseguradora_cod_susep());
        values.add(produto.getnum_max_parcela());
		jdbcTemplate.update(sql, values.toArray());
	}
	
	public void update(Produto_tb produto) {
		String sql = "update produto_tb set nome = ?, seguradora_cod_susep = ?, num_max_parcela = ? where produto_id = ?";
		List<Object> values = new ArrayList<>();
        values.add(produto.getNome());
        values.add(produto.getseguradora_cod_susep());
        values.add(produto.getnum_max_parcela());
        values.add(produto.getproduto_id());
		jdbcTemplate.update(sql, values.toArray());
	}

	public void delete(Produto_tb produto) {
		String sql = "delete produto_tb where produto_id = ?";
		jdbcTemplate.update(sql, produto.getproduto_id());
	}
	
	
}
